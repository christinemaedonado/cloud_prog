import time

# Initialize an empty list to store tasks
tasks = []

# Function to add a task to the task list
def add_task():
    task_name = input("Enter the task name: ")  # Prompt user to enter task name
    task_time = input("Enter the task time in seconds: ")  # Prompt user to enter task time in seconds
    
    # Create a task dictionary with 'name' and 'time'
    task = {
        "name": task_name,
        "time": int(task_time)
    }
    
    # Append the task to the tasks list
    tasks.append(task)
    
    # Print confirmation message
    print("Task added successfully!")

# Function to run the task scheduler
def run_scheduler():
    print("Task scheduler started!")
    
    # Run the scheduler as long as there are tasks in the list
    while tasks:
        task = tasks.pop(0)  # Remove the first task from the list
        print(f"Running task: {task['name']}")  # Print task name
        
        # Sleep for the specified task time
        time.sleep(task["time"])
        
        # Print task completion message
        print(f"Task {task['name']} completed!")

# Main function to handle user interaction and menu
def main():
    while True:
        # Display menu options
        print("\nMenu:")
        print("1. Add a task")
        print("2. Run scheduler")
        print("3. Exit")
        
        # Prompt user to choose an option
        choice = input("Enter your choice: ")
        
        # Check the user's choice and call the respective function
        if choice == '1':
            add_task()  # Add a task
        elif choice == '2':
            run_scheduler()  # Run the scheduler
        elif choice == '3':
            break  # Exit the program
        else:
            print("Invalid choice. Please try again.")  # Handle invalid choices

# Check if the script is being run directly
if __name__ == "__main__":
    main()  # Call the main function to start the program
